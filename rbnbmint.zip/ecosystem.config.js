module.exports = {
  apps: [
    {
      name: 'app1',
      script: './index.js',
      instances: 2,
    },
  ],
}
